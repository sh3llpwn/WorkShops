#!/bin/bash 
echo $0
echo "\$name"

