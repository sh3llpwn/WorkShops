
#!/bin/bash 

if [ 10 -gt 100 ] 
then 
echo "a"
elif [ 10 -gt 2 ]
then
echo "b"
else 
echo "c"
fi 
