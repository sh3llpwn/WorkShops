#!/bin/bash 

name="Divy"
echo $name

echo "My name is ${name}ytx"

read lastname

echo $lastname

read -p "Enter ur lastname" lastname 
echo $lastname 

