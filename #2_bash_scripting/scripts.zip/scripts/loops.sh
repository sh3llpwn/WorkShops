#!/bin/bash 

for i in {1..10}
do
	echo "$i"
done

for ((i=0;i<10;i++))
do
	echo "$i"
done


