#!/bin/bash 

function test_foo()
{
if [ 10 -gt 1 ]
then echo "inside the func"
fi
}

test_foo

