#!/bin/bash 

cat /home/divy/Desktop/file.txt | grep "flag" 
ls -la
